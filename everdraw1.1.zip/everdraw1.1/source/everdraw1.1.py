import tkinter as tk
from tkinter import filedialog
import json
import os
import itertools


class DrawingCanvas(tk.Canvas):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.bind("<B1-Motion>", self.draw)
        self.paths = []
        self.current_color = "black"

    def draw(self, event):
        x, y = event.x, event.y
        r = 2
        self.create_oval(x - r, y - r, x + r, y + r,
                         fill=self.current_color,
                         outline=self.current_color)
        self.paths.append({"x": x, "y": y, "color": self.current_color})

    def get_data(self):
        return {"paths": self.paths}

    def load_data(self, data):
        self.delete("all")
        self.paths = data.get("paths", [])
        for stroke in self.paths:
            x, y = stroke["x"], stroke["y"]
            color = stroke.get("color", "black")
            self.create_oval(x - 2, y - 2, x + 2, y + 2,
                             fill=color, outline=color)


def save_canvas(data, filename):
    if not filename.endswith(".epc"):
        filename += ".epc"
    with open(filename, "w") as file:
        json.dump(data, file)

def load_canvas(filename):
    if not os.path.exists(filename):
        print(f"File '{filename}' not found.")
        return None
    with open(filename, "r") as file:
        return json.load(file)

# Yes, i changed the code message for 1.1, because coding this is hard enough.
root = tk.Tk()
root.title("EverDraw")
canvas = DrawingCanvas(root, bg="white", width=800, height=600)
canvas.pack()


colors = ["black", "red", "blue", "green", "purple", "orange", "hotpink"]
def set_color(c):
    canvas.current_color = c

for color in colors:
    tk.Button(root, bg=color, width=2,
              command=lambda c=color: set_color(c)).pack(side="left")


def clear_canvas():
    canvas.delete("all")
    canvas.paths = []

tk.Button(root, text="Clear", command=clear_canvas).pack(side="left")


def save():
    file = filedialog.asksaveasfilename(defaultextension=".epc")
    if file:
        save_canvas(canvas.get_data(), file)

def load():
    file = filedialog.askopenfilename(filetypes=[("EPC Files", "*.epc")])
    if file:
        data = load_canvas(file)
        if data:
            canvas.load_data(data)

tk.Button(root, text="Save", command=save).pack(side="left")
tk.Button(root, text="Load", command=load).pack(side="left")

# 🌈 Konami Code Easter Egg (Rainbow Brush)
konami_sequence = ["Up", "Up", "Down", "Down", "Left", "Right", "Left", "Right"]
current_input = []

def activate_rainbow_mode():
    rainbow_colors = itertools.cycle(["red", "orange", "yellow", "green", "blue", "indigo", "violet"])
    def rotate():
        canvas.current_color = next(rainbow_colors)
        canvas.after(150, rotate)
    rotate()
  

def on_key_press(event):
    key = event.keysym.lower()
    mapped = key.capitalize() if key.isalpha() else key
    current_input.append(mapped)
    if len(current_input) > len(konami_sequence):
        current_input.pop(0)
    if current_input == konami_sequence:
        activate_rainbow_mode()

root.bind("<KeyPress>", on_key_press)


root.mainloop()