import tkinter as tk
from tkinter import filedialog, colorchooser, messagebox
import json
import os
import itertools

class DrawingCanvas(tk.Canvas):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.bind("<B1-Motion>", self.draw)
        self.bind("<Button-1>", self.click_draw)
        self.bind("<Alt-Button-1>", self.color_sample)
        self.paths = []
        self.current_color = "black"
        self.pen_size = 4

    def click_draw(self, event):
        self.draw(event)

    def draw(self, event):
        x, y = event.x, event.y
        r = self.pen_size // 2
        self.create_oval(x - r, y - r, x + r, y + r, fill=self.current_color, outline=self.current_color)
        self.paths.append({"x": x, "y": y, "color": self.current_color, "size": self.pen_size})

    def color_sample(self, event):
        ids = self.find_closest(event.x, event.y)
        if ids:
            color = self.itemcget(ids[0], "fill")
            if color:
                self.current_color = color

    def get_data(self):
        return {"paths": self.paths}

    def load_data(self, data):
        self.delete("all")
        self.paths = data.get("paths", [])
        for stroke in self.paths:
            x = stroke["x"]
            y = stroke["y"]
            color = stroke.get("color", "black")
            size = stroke.get("size", 4)
            r = size // 2
            self.create_oval(x - r, y - r, x + r, y + r, fill=color, outline=color)

def save_canvas(data, filename):
    if not filename.endswith(".epc"):
        filename += ".epc"
    with open(filename, "w") as file:
        json.dump(data, file)

def load_canvas(filename):
    if not os.path.exists(filename):
        return None
    with open(filename, "r") as file:
        return json.load(file)

root = tk.Tk()
root.title("EverDraw 1.2")
canvas = DrawingCanvas(root, bg="white", width=800, height=600)
canvas.pack()

pen_frame = tk.Frame(root)
tk.Label(pen_frame, text="Size:").pack(side="left")
for size in [2, 4, 8, 16]:
    tk.Button(pen_frame, text=str(size), command=lambda s=size: setattr(canvas, "pen_size", s)).pack(side="left")
pen_frame.pack()

colors = ["black", "red", "blue", "green", "purple", "orange", "hotpink"]
for color in colors:
    tk.Button(root, bg=color, width=2, command=lambda c=color: setattr(canvas, "current_color", c)).pack(side="left")

def pick_color():
    color = colorchooser.askcolor(title="Pick a Color")[1]
    if color:
        canvas.current_color = color

tk.Button(root, text="Custom", command=pick_color).pack(side="left")

def clear_canvas():
    if messagebox.askyesno("Confirm Clear", "Erase all drawings?"):
        canvas.delete("all")
        canvas.paths = []

tk.Button(root, text="Clear", command=clear_canvas).pack(side="left")

def save():
    file = filedialog.asksaveasfilename(defaultextension=".epc")
    if file:
        save_canvas(canvas.get_data(), file)

def load():
    file = filedialog.askopenfilename(filetypes=[("EPC Files", "*.epc")])
    if file:
        data = load_canvas(file)
        if data:
            canvas.load_data(data)

tk.Button(root, text="Save", command=save).pack(side="left")
tk.Button(root, text="Load", command=load).pack(side="left")

konami_sequence = ["Up", "Up", "Down", "Down", "Left", "Right", "Left", "Right"]
current_input = []

def activate_rainbow_mode():
    rainbow = itertools.cycle(["red", "orange", "yellow", "green", "blue", "indigo", "violet"])
    def swirl():
        canvas.current_color = next(rainbow)
        canvas.after(120, swirl)
    swirl()

def on_key(event):
    key = event.keysym.lower()
    mapped = key.capitalize() if key.isalpha() else key
    current_input.append(mapped)
    if len(current_input) > len(konami_sequence):
        current_input.pop(0)
    if current_input == konami_sequence:
        activate_rainbow_mode()

root.bind("<KeyPress>", on_key)
root.mainloop()