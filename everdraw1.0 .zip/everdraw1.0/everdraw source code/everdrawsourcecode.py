# Credit to Copilot for helping me with this!

import tkinter as tk
from tkinter import filedialog
import json
import os


class DrawingCanvas(tk.Canvas):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.bind("<B1-Motion>", self.draw)
        self.paths = []

    def draw(self, event):
        x, y = event.x, event.y
        r = 2
        self.create_oval(x - r, y - r, x + r, y + r, fill="black")
        self.paths.append((x, y))

    def get_data(self):
        return {"paths": self.paths}

    def load_data(self, data):
        self.paths = data.get("paths", [])
        for x, y in self.paths:
            self.create_oval(x - 2, y - 2, x + 2, y + 2, fill="black")


def save_canvas(data, filename):
    if not filename.endswith(".epc"):
        filename += ".epc"
    with open(filename, "w") as file:
        json.dump(data, file)

def load_canvas(filename):
    if not os.path.exists(filename):
        print(f"File '{filename}' not found.")
        return None
    with open(filename, "r") as file:
        return json.load(file)

# This file format (.epc) could be called Everiff or EverDraw Image File.
root = tk.Tk()
root.title("EverDraw")
canvas = DrawingCanvas(root, bg="white", width=800, height=600)
canvas.pack()

def save():
    file = filedialog.asksaveasfilename(defaultextension=".epc")
    if file:
        save_canvas(canvas.get_data(), file)

def load():
    file = filedialog.askopenfilename(filetypes=[("EPC Files", "*.epc")])
    if file:
        data = load_canvas(file)
        if data:
            canvas.load_data(data)

tk.Button(root, text="Save", command=save).pack(side="left")
tk.Button(root, text="Load", command=load).pack(side="left")

root.mainloop()